# !/bin/bash
#proyecto Wawakipu
# AUTHOR: MEDIALAB
# CONTACT info@wawakipu.com

echo "Instalador Wawakipu"
mkdir ~/Scratch
cp -R ./Media/ ~/Scratch/
cp -R ./Projects/ ~/Scratch/
echo "Wawakipu 0.1 instalado"
ls ~/Scratch/

echo "Instalador Scratch"
sudo apt-get -y install imagemagick
sudo apt-get -y install scratch
echo "Scratch ha sido instalado"

cd /usr/share/scratch/Media/

#pwd
if [ -f /usr/bin/scratch ]; then
	echo Scratch Instalado

	if [ -f /usr/bin/mogrify ]; then
		echo Convirtiendo JPGs en PNGs
		sudo find . -iname "*.jpg" -exec mogrify -format png {} \;
		echo Eliminando JPGs
		sudo find . -iname "*.jpg" -exec rm -f {} \;
		open  http://www.wawakipu.com/

	else
		echo "No se encuentra instalado el convertidor de imagenes, no se podran cargar imagenes jpg en el scratch."

	fi

else
	echo "Scratch No Instalado"

fi


cd ~
exit 0
